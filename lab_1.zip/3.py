char = str(input("Введите символ: "))
word = str(input("Введите строку: "))
a = 0

for i in range(len(word)):
  if word[i] == char:
    a += 1
    if a == 2:
      print(i)
      break