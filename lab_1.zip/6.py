a = input("Введите массив через пробелы: ")
a = a.split()
b = True

for i in a:
  if not i == a[0]:
    b = False
    break

if b: print("Состоит")
else: print("Не состоит")