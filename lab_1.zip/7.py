a, b, c, d = False, False, False, False
password = input("Введите пароль для проверки: ")

while len(password) < 16:
  password = input("Введите пароль длинее 16 символов: ")

for i in password:
  if i.islower(): a = True
  elif i.isupper(): b = True
  elif i.isnumeric(): c = True
  else: d = True

if a and b and c and not d: print("Крутой пароль!!1")
else: print("Плохой пароль, меняй")