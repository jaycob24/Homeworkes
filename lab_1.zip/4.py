str = str(input("Введите строку: "))
zs  = 0

for i in reversed(str):
  if (i == "0"):
    zs += 1
  else:
    break

print(zs)