a = [4, 15, 20, 20, 15, 18, 5, 20, 15, 19, 8, 1]
d = {}
res = []

for i in a:
  if not i in d:
    d[i] = 1
  else:
    d[i] += 1

for i in a:
  if not d[i] == 1:
    res.append(i)

print(res)