d = {'a' : 0.01, 'b' : 0.03, 'c' : 10.3, 'd' : 9.15}
max = 0
maxkey = ''

for key in d:
  if d[key] > max:
    maxkey = key
    max = d[key]

print(maxkey, ':', max)