a = input("Введите строку: ")
b = ""

for c in reversed(a):
	b += c

print(b)