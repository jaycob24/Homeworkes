def PrintIndex(a, i):
  print(a[i])

a = [1, 2, 3, 4]
PrintIndex(a, 0)
PrintIndex(a, 2)
PrintIndex(a, -2)