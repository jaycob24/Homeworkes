a = [[1, 2], [[3, 4], 5], 6]

for x in a:
  if type(x) is list:
    for y in x:
      if type(y) is list:
        for z in y: print(z)
      else: print(y)
  else: print(x)