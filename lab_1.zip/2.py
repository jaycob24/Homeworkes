a = [1, 2, 3, 4]
N = int(input("Введите число: "))

if N < len(a):
  print(a[N] ** N)
else:
  print("-1")